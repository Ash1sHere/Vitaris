USE vitaris_db;
UPDATE patients 
SET 
    full_name = NULL, 
    dob = NULL, 
    blood_group = NULL, 
    gender = NULL, 
    pin = NULL 
WHERE patient_id IN ('42C111BE', '72EC0EBE', 'C2FC0ABE', 'E20B06BE');
