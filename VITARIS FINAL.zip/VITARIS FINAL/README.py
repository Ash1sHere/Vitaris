# Our project includes multiple files. Here is a drive link to all of them: https://drive.google.com/drive/folders/1XvZuaM-qsOJ2VNyJ33R5Qkt5-e0nRJG3?usp=sharing
# API key, Flask secret key and database password has been removed
# EXE file for doctor's interface has not been uploaded as it has sensitive information. Python file has all the necessary code excluding the same.