from flask import Flask, render_template, request, redirect, url_for, flash, session
import mysql.connector

app = Flask(__name__)
app.secret_key = 'SECRET_KEY'  

def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",  
        password="password",  
        database="vitaris_db"
    )

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':

        full_name = request.form['full_name']
        dob = request.form['dob']
        blood_group = request.form['blood_group']
        gender = request.form['gender']
        pin = request.form['pin']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT patient_id FROM patients WHERE full_name IS NULL LIMIT 1")
        empty_patient = cursor.fetchone()

        if empty_patient:
            patient_id = empty_patient[0]

            cursor.execute(""" 
                UPDATE patients
                SET full_name = %s, dob = %s, blood_group = %s, gender = %s, pin = %s
                WHERE patient_id = %s
            """, (full_name, dob, blood_group, gender, pin, patient_id))
            conn.commit()
            flash('Signup successful! Please login.', 'success')
            return redirect(url_for('login'))

        flash('No empty patient IDs available. Please try again later.', 'error')
        return redirect(url_for('signup'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        pin = request.form['pin']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM patients WHERE patient_id = %s AND pin = %s", (patient_id, pin))
        patient = cursor.fetchone()

        if patient:
            session['patient_id'] = patient['patient_id']
            session['full_name'] = patient['full_name']
            return redirect(url_for('dashboard'))

        else:
            flash("Invalid login, please try again.", 'error')

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'patient_id' not in session:
        return redirect(url_for('login'))

    first_name = session['full_name'].split()[0]
    return render_template('dashboard.html', first_name=first_name)

@app.route('/view_prescriptions')
def view_prescriptions():
    if 'patient_id' not in session:
        return redirect(url_for('login'))

    patient_id = session['patient_id']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT p.created_at, p.prescription_details, d.doc_name
        FROM prescriptions p
        JOIN doctors d ON p.doc_user = d.doc_user
        WHERE p.patient_id = %s
        ORDER BY p.created_at DESC
    """, (patient_id,))
    prescriptions = cursor.fetchall()

    for prescription in prescriptions:
        prescription['prescription_details'] = prescription['prescription_details'].replace(';', '<br>')

    return render_template('view_prescriptions.html', prescriptions=prescriptions)

@app.route('/view_medical_history')
def view_medical_history():
    if 'patient_id' not in session:
        return redirect(url_for('login'))

    patient_id = session['patient_id']

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT h.created_at, h.history_details, d.doc_name
        FROM history h
        JOIN doctors d ON h.doc_user = d.doc_user
        WHERE h.patient_id = %s
        ORDER BY h.created_at DESC
    """, (patient_id,))
    medical_history = cursor.fetchall()

    for history in medical_history:
        history['history_details'] = history['history_details'].replace(';', '<br>')

    return render_template('view_medical_history.html', medical_history=medical_history)

@app.route('/book_appointment', methods=['GET', 'POST'])
def book_appointment():
    """Page where a patient can view vacancies for a doctor and book an appointment."""  

    patient_id = session['patient_id']  
    doc_user = None
    vacancies = []
    doc_name = None  

    if request.method == 'POST':

        if 'doc_user' in request.form:
            doc_user = request.form['doc_user'].strip()

            if doc_user:
                conn = get_db_connection()
                cursor = conn.cursor(dictionary=True)

                cursor.execute("""
                    SELECT doc_name FROM doctors WHERE LOWER(doc_user) = LOWER(%s)
                """, (doc_user,))
                doctor = cursor.fetchone()

                if doctor:
                    doc_name = doctor['doc_name']

                    cursor.execute("""
                        SELECT vacancy_id, vacancy_datetime
                        FROM vacancies
                        WHERE LOWER(doc_user) = LOWER(%s)
                    """, (doc_user,))
                    vacancies = cursor.fetchall()
                else:
                    flash('Invalid doctor username. Please try again.', 'error')

                cursor.close()
                conn.close()

        elif 'vacancy_id' in request.form:
            vacancy_id = request.form['vacancy_id']
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)

            cursor.execute("""
                SELECT * FROM vacancies WHERE vacancy_id = %s
            """, (vacancy_id,))
            vacancy = cursor.fetchone()

            if vacancy:

                cursor.execute("""
                    INSERT INTO appointments (patient_id, appointment_datetime, doc_user)
                    VALUES (%s, %s, %s)
                """, (patient_id, vacancy['vacancy_datetime'], vacancy['doc_user']))

                cursor.execute("""
                    DELETE FROM vacancies WHERE vacancy_id = %s
                """, (vacancy_id,))

                conn.commit()
                flash('Appointment successfully booked.', 'success')

            if doc_user:
                cursor.execute("""
                    SELECT vacancy_id, vacancy_datetime
                    FROM vacancies
                    WHERE LOWER(doc_user) = LOWER(%s)
                """, (doc_user,))
                vacancies = cursor.fetchall()

            cursor.close()
            conn.close()

    return render_template('book_appointment.html', vacancies=vacancies, doc_user=doc_user, doc_name=doc_name)

@app.route('/view_appointments')
def view_appointments():

    if 'patient_id' not in session:
        flash('Please log in to view your appointments.', 'error')
        return redirect(url_for('login'))

    patient_id = session['patient_id']  

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT 
            appointments.appointment_datetime,
            doctors.doc_name
        FROM 
            appointments
        JOIN 
            doctors ON appointments.doc_user = doctors.doc_user
        WHERE 
            appointments.patient_id = %s
        ORDER BY 
            appointments.appointment_datetime ASC
    """, (patient_id,))

    appointments = cursor.fetchall()

    cursor.close()
    conn.close()  

    if not appointments:
        flash("You have no appointments at the moment.", 'info')

    return render_template('appointments.html', appointments=appointments)

@app.route('/logout')
def logout():

    session.pop('patient_id', None)
    session.pop('full_name', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)