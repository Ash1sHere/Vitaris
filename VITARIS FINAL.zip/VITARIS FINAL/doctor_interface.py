import serial
import time
import mysql.connector
import tkinter as tk
from tkcalendar import Calendar
from tkinter import ttk, messagebox, scrolledtext
import threading
import openai

main_window = tk.Tk()  

openai.api_key = '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'

db = mysql.connector.connect(
    host="127.0.0.1",       
    user="root",            
    password="rT4%^678",    
    database="vitaris_db"   
)

serial_port = "COM6"  
baud_rate = 9600

ser = None
serial_connected = False  

doc_user = ""  

def read_serial_data():
    if serial_connected:
        verify_patient()  
    main_window.after(1000, read_serial_data)  

def initialize_serial():
    global ser, serial_connected
    if not serial_connected:
        try:
            ser = serial.Serial(serial_port, baud_rate)
            time.sleep(2)  
            serial_connected = True
            print("Serial connection established.")

            serial_thread = threading.Thread(target=serial_loop)
            serial_thread.daemon = True  
            serial_thread.start()  

            read_serial_data()  
        except serial.SerialException as e:
            print(f"Error: {e}")
            ser = None  
            serial_connected = False

def serial_loop():
    while serial_connected:
        if ser and ser.is_open:  
            try:

                if ser.in_waiting > 0:
                    card_uid = ser.readline().decode('utf-8').strip()
                    print(f"Patient ID: {card_uid}")  

                    patient_id_label.config(text=f"Patient ID: {card_uid}")

                    query = f"SELECT * FROM patients WHERE patient_id = '{card_uid}'"
                    cursor = db.cursor()
                    cursor.execute(query)
                    result = cursor.fetchone()

                    if result:
                        pin = result[5]  
                        print(f"Sending PIN to Arduino: {pin}")  
                        ser.write(f"{pin}\n".encode())  

                        arduino_response = ser.readline().decode('utf-8').strip()
                        print(f"Arduino response: {arduino_response}")  

                        if arduino_response == "verified":
                            full_name = result[1]  
                            dob = result[2].strftime('%d-%m-%Y')        
                            blood_group = result[3]  
                            gender = result[4]      

                            name_label.config(text=f"Full Name: {full_name}")
                            dob_label.config(text=f"Date of Birth: {dob}")
                            blood_group_label.config(text=f"Blood Group: {blood_group}")
                            gender_label.config(text=f"Gender: {gender}")
                        else:

                            print("PIN verification failed.")
                    else:

                        print("Patient ID not found in the database.")
            except serial.SerialException:
                messagebox.showerror("Error", "Error: Scanner not detected.")
                close_serial()  
            except Exception as e:
                print(f"An error occurred: {str(e)}")

def close_serial():
    global ser, serial_connected
    if ser and ser.is_open:
        ser.close()
        serial_connected = False
        print("Serial connection closed.")

def verify_patient():
    if ser and ser.is_open:  
        try:

            if ser.in_waiting > 0:
                card_uid = ser.readline().decode('utf-8').strip()
                print(f"Patient ID: {card_uid}")  

                patient_id_label.config(text=f"Patient ID: {card_uid}")

                query = f"SELECT * FROM patients WHERE patient_id = '{card_uid}'"
                cursor = db.cursor()
                cursor.execute(query)
                result = cursor.fetchone()

                if result:
                    pin = result[5]  
                    print(f"Sending PIN to Arduino: {pin}")  
                    ser.write(f"{pin}\n".encode())  

                    arduino_response = ser.readline().decode('utf-8').strip()
                    print(f"Arduino response: {arduino_response}")  

                    if arduino_response == "verified":
                        full_name = result[1]  
                        dob = result[2]        
                        blood_group = result[3]  
                        gender = result[4]      

                        name_label.config(text=f"Full Name: {full_name}")
                        dob_label.config(text=f"Date of Birth: {dob}")
                        blood_group_label.config(text=f"Blood Group: {blood_group}")
                        gender_label.config(text=f"Gender: {gender}")
                    else:

                        print("PIN verification failed.")
                else:

                    print("Patient ID not found in the database.")
        except serial.SerialException:
            messagebox.showerror("Error", "Error: Scanner not detected.")
            close_serial()  
        except Exception as e:
            print(f"An error occurred: {str(e)}")

def read_serial_data():
    if serial_connected:
        verify_patient()  
    main_window.after(1000, read_serial_data)  

def clear():
    patient_id_label.config(text="Patient ID: ")
    name_label.config(text="Full Name: ")
    dob_label.config(text="Date of Birth: ")
    blood_group_label.config(text="Blood Group: ")
    gender_label.config(text="Gender: ")

def toggle_serial():
    global serial_connected
    if serial_connected:
        close_serial()  
        serial_button.config(text="Connect")  
    else:
        initialize_serial()  
        serial_button.config(text="Disconnect")  

def process_ai_input():
    prescription_raw = raw_prescription.get("1.0", "end-1c")
    history_raw = raw_history.get("1.0", "end-1c")

    prescription_list = []
    history_list = []

    if prescription_raw:

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{
                "role": "system",
                "content": (
                    "You are a doctor's assistant. Your job is to classify and process prescriptions that the doctor will give you concisely. "
                    "Do not add any additional text, only classify and process the data. For prescriptions, the first line specifies the type (choose from Drug Prescription, Eyewear Prescription, Dietary Prescription, Dental Prescription, Equipment Prescription(for inhalers, nebulizers etc.)). "
                    "Subsequent lines list the parameters (e.g., Drug:, Dosage:). But the first line only has the prescription type."
                    "In case of insufficient data, ONLY type 'Insufficient Data'."
                )
            },
            {"role": "user", "content": prescription_raw}]
        )

        ai_response = response['choices'][0]['message']['content']
        entries = ai_response.split("\n\n")

        for entry in entries:
            lines = entry.strip().split("\n")
            current_prescription_list = [line.strip().lstrip('-').strip() for line in lines if line.strip()]
            if current_prescription_list:  
                prescription_list.append(';'.join(current_prescription_list))

    if history_raw:

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{
                "role": "system",
                "content": (
                    "You are a doctor's assistant. Your job is to classify and process medical history that the doctor will give you concisely. "
                    "Do not add any additional text, only classify and process the data. For medical history, the first line specifies the type (choose from Diagnosis Report, Vaccination Report, Procedural Report(for surgeries, xrays etc.), Lab Report). "
                    "The second line contains the details, summarized concisely but clearly."
                    "In case of insufficient data, ONLY type 'Insufficient Data'."
                )
            },
            {"role": "user", "content": history_raw}]
        )

        ai_response = response['choices'][0]['message']['content']
        entries = ai_response.split("\n\n")

        for entry in entries:
            lines = entry.strip().split("\n")
            current_history_list = [line.strip().lstrip('-').strip() for line in lines if line.strip()]
            if current_history_list:  
                history_list.append(';'.join(current_history_list))

    if prescription_list == ['Insufficient Data'] or history_list == ['Insufficient Data']:
        messagebox.showinfo("Insufficient Data", "Insufficient Data. No information saved.")
        return  

    cursor = db.cursor()
    global doc_user  

    for prescription in prescription_list:
        cursor.execute(
            "INSERT INTO prescriptions (patient_id, prescription_details, doc_user) VALUES (%s, %s, %s)",
            (patient_id_label.cget("text").split(":")[1].strip(), prescription, doc_user)
        )

    for history in history_list:
        cursor.execute(
            "INSERT INTO history (patient_id, history_details, doc_user) VALUES (%s, %s, %s)",
            (patient_id_label.cget("text").split(":")[1].strip(), history, doc_user)
        )

    db.commit()
    cursor.close()
    messagebox.showinfo("Success", "Prescription and history data saved successfully!")

def doctor_login():
    global doc_user

    login_window = tk.Tk()  
    login_window.title("Doctor Login")
    login_window.geometry("300x250")
    login_window.resizable(False, False)

    login_window.grab_set()
    login_window.focus_force()

    def verify_login():
        global doc_user
        username = username_entry.get().strip()
        password = password_entry.get().strip()

        if not username or not password:
            messagebox.showerror("Error", "Please fill in all fields.")
            return

        try:
            cursor = db.cursor()
            query = "SELECT doc_name FROM doctors WHERE doc_user = %s AND doc_pass = %s"
            cursor.execute(query, (username, password))
            result = cursor.fetchone()
            cursor.close()
        except Exception as e:
            messagebox.showerror("Error", f"Database error: {e}")
            return

        if result:
            doc_user = username
            doc_name = result[0]  
            messagebox.showinfo("Login Successful", f"Welcome Dr. {doc_name}!")
            login_window.destroy()  
            main_application()  
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    def on_enter(event=None):
        verify_login()

    tk.Label(login_window, text="Doctor Login", font=("Segoe UI", 16, "bold")).pack(pady=10)

    tk.Label(login_window, text="Username:", font=("Segoe UI", 12)).pack(pady=5)
    username_entry = tk.Entry(login_window, font=("Segoe UI", 12))
    username_entry.pack(pady=5)
    username_entry.focus()  

    tk.Label(login_window, text="Password:", font=("Segoe UI", 12)).pack(pady=5)
    password_entry = tk.Entry(login_window, font=("Segoe UI", 12), show="*")
    password_entry.pack(pady=5)
    password_entry.bind("<Return>", on_enter)  

    login_button = tk.Button(login_window, text="Login", command=verify_login, font=("Segoe UI", 12))
    login_button.pack()

    login_window.mainloop()

def main_application():
    global raw_prescription, raw_history, patient_id_label, name_label, dob_label, blood_group_label, gender_label
    global serial_button, prescriptions_text, history_text, doc_user, viewer_text, current_view_mode

    main_window.title("Vitaris - Doctor's Dashboard")  
    main_window.geometry("1920x1080")

    main_window.grid_rowconfigure(0, weight=1)
    main_window.grid_columnconfigure(0, weight=1)
    main_window.grid_columnconfigure(1, weight=3)
    main_window.grid_columnconfigure(2, weight=2)

    left_frame = tk.Frame(main_window)
    left_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

    patient_id_label = tk.Label(left_frame, text="Patient ID: ", font=("Segoe UI", 10))
    patient_id_label.grid(row=0, column=0, pady=5, sticky="w")

    name_label = tk.Label(left_frame, text="Full Name: ", font=("Segoe UI", 10))
    name_label.grid(row=1, column=0, pady=5, sticky="w")

    dob_label = tk.Label(left_frame, text="Date of Birth: ", font=("Segoe UI", 10))
    dob_label.grid(row=2, column=0, pady=5, sticky="w")

    blood_group_label = tk.Label(left_frame, text="Blood Group: ", font=("Segoe UI", 10))
    blood_group_label.grid(row=3, column=0, pady=5, sticky="w")

    gender_label = tk.Label(left_frame, text="Gender: ", font=("Segoe UI", 10))
    gender_label.grid(row=4, column=0, pady=5, sticky="w")

    serial_button = tk.Button(left_frame, text="Connect", font=("Segoe UI", 10), command=lambda: toggle_serial(), relief="raised")
    serial_button.grid(row=5, column=0, pady=7)

    clear_button = tk.Button(left_frame, text="Clear", font=("Segoe UI", 10), command=lambda: clear(), relief="raised")
    clear_button.grid(row=6, column=0, pady=7)

    open_vacancies_button = tk.Button(left_frame, text="Manage Vacancies", font=("Segoe UI", 10), command=lambda: open_vacancies_window(), relief="raised")
    open_vacancies_button.grid(row=7, column=0, pady=7)

    input_frame = tk.Frame(main_window, padx=30, pady=10, relief="groove", borderwidth=1)
    input_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")

    raw_prescription = scrolledtext.ScrolledText(input_frame, wrap=tk.WORD, width=40, height=10)
    raw_prescription.grid(row=0, column=1, pady=5)
    raw_prescription.insert(tk.END, "Enter prescription details here...")

    raw_history = scrolledtext.ScrolledText(input_frame, wrap=tk.WORD, width=40, height=10)
    raw_history.grid(row=1, column=1, pady=5)
    raw_history.insert(tk.END, "Enter medical history here...")

    process_button = tk.Button(input_frame, text="Process and Save", font=("Segoe UI", 12), command=lambda: process_ai_input())
    process_button.grid(row=2, column=1, pady=20)

    viewer_frame = tk.Frame(main_window, padx=20, pady=20, relief="groove", borderwidth=1)
    viewer_frame.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")

    prescription_button = tk.Button(viewer_frame, text="View Prescriptions", font=("Segoe UI", 12), command=lambda: load_prescription_history('prescription'))
    prescription_button.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

    history_button = tk.Button(viewer_frame, text="View History", font=("Segoe UI", 12), command=lambda: load_prescription_history('history'))
    history_button.grid(row=0, column=1, padx=10, pady=10, sticky="ew")

    viewer_text = scrolledtext.ScrolledText(viewer_frame, wrap=tk.WORD, width=60, height=30)
    viewer_text.grid(row=1, column=0, columnspan=2, pady=10)

    main_window.mainloop()

def clear():
    patient_id_label.config(text="Patient ID: ")
    name_label.config(text="Full Name: ")
    dob_label.config(text="Date of Birth: ")
    blood_group_label.config(text="Blood Group: ")
    gender_label.config(text="Gender: ")

def load_prescription_history(view_type):
    global viewer_text

    if view_type == 'prescription':
        table_name = 'prescriptions'
        details_column = 'prescription_details'
    elif view_type == 'history':
        table_name = 'history'
        details_column = 'history_details'
    else:
        return

    try:
        cursor = db.cursor(dictionary=True)

        query = f"""
            SELECT p.created_at, p.{details_column}, d.doc_name 
            FROM {table_name} p
            JOIN doctors d ON p.doc_user = d.doc_user
            WHERE p.patient_id = %s 
            ORDER BY p.created_at DESC
        """
        cursor.execute(query, (patient_id_label.cget("text").split(":")[1].strip(),))
        records = cursor.fetchall()
        cursor.close()
    except Exception as e:
        messagebox.showerror("Error", f"Database error: {e}")
        return

    viewer_text.delete("1.0", tk.END)

    if not records:
        viewer_text.insert(tk.END, f"No {view_type} records found for this patient.")
    else:

        for record in records:

            created_at = record.get('created_at')
            if created_at:
                formatted_date = created_at.strftime("%d-%m-%Y %H:%M")
            else:
                formatted_date = 'Unknown Date'

            details = record.get(details_column, 'No details available')
            doctor_name = record.get('doc_name', 'Unknown Doctor')

            formatted_details = details.replace(";", "\n")

            viewer_text.insert(tk.END, f"Created At: {formatted_date}\nDoctor: {doctor_name}\n{formatted_details}\n{'-'*40}\n")

def open_vacancies_window():
    vacancies_window = tk.Toplevel(main_window)
    vacancies_window.title("Manage Vacancies")
    vacancies_window.geometry("1600x900")  

    vacancy_frame = tk.Frame(vacancies_window, relief="groove", borderwidth=1, padx=20, pady=20)
    vacancy_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

    tk.Label(vacancy_frame, text="Add Vacancy", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, pady=10, columnspan=2)

    tk.Label(vacancy_frame, text="Select Date:", font=("Segoe UI", 10)).grid(row=1, column=0, sticky="w")
    calendar = Calendar(vacancy_frame, date_pattern="yyyy-mm-dd")
    calendar.grid(row=2, column=0, columnspan=2, pady=10)

    tk.Label(vacancy_frame, text="Select Time (HH:MM):", font=("Segoe UI", 10)).grid(row=3, column=0, sticky="w")

    hour_input = ttk.Spinbox(vacancy_frame, from_=0, to=23, width=3, format='%02.0f')
    hour_input.grid(row=4, column=0, padx=(10, 2), pady=5, sticky="w")
    hour_input.set("09")  

    tk.Label(vacancy_frame, text=":", font=("Segoe UI", 12)).grid(row=4, column=0, padx=(50, 0), sticky="w")

    minute_input = ttk.Spinbox(vacancy_frame, from_=0, to=59, width=3, format='%02.0f')
    minute_input.grid(row=4, column=0, padx=(65, 0), pady=5, sticky="w")
    minute_input.set("00")

    def submit_vacancy():
        selected_date = calendar.get_date()
        hour = hour_input.get()
        minute = minute_input.get()

        vacancy_datetime = f"{selected_date} {hour}:{minute}:00"

        try:
            cursor = db.cursor()
            sql = "INSERT INTO vacancies (vacancy_datetime, doc_user) VALUES (%s, %s)"
            cursor.execute(sql, (vacancy_datetime, doc_user))
            db.commit()
            cursor.close()
            messagebox.showinfo("Success", f"Vacancy successfully added for {vacancy_datetime}.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    submit_button = tk.Button(vacancy_frame, text="Add Vacancy", command=submit_vacancy)
    submit_button.grid(row=5, column=0, pady=20, columnspan=2)

    vacancy_display_frame = tk.Frame(vacancies_window, relief="groove", borderwidth=1, padx=20, pady=20)
    vacancy_display_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew", rowspan=2)

    tk.Label(vacancy_display_frame, text="Vacancies", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, pady=10)

    vacancy_display_text = scrolledtext.ScrolledText(vacancy_display_frame, wrap=tk.WORD, width=60, height=20)
    vacancy_display_text.grid(row=1, column=0, pady=10)
    vacancy_display_text.config(state=tk.DISABLED)  

    def display_current_vacancies():
        cursor = db.cursor()
        cursor.execute(
            "SELECT vacancy_datetime FROM vacancies WHERE doc_user = %s ORDER BY vacancy_datetime DESC", 
            (doc_user,)  
        )
        vacancies = cursor.fetchall()
        cursor.close()

        vacancy_display_text.config(state=tk.NORMAL)
        vacancy_display_text.delete(1.0, tk.END)  

        if vacancies:
            for vacancy_datetime in vacancies:

                formatted_datetime = vacancy_datetime[0].strftime("%d-%m-%Y %H:%M")
                vacancy_display_text.insert(tk.END, f"Vacancy: {formatted_datetime}\n{'-'*40}\n")
        else:
            vacancy_display_text.insert(tk.END, "No vacancies posted.")

        vacancy_display_text.config(state=tk.DISABLED)  

    display_current_vacancies()

    refresh_vacancies_button = tk.Button(vacancy_display_frame, text="Refresh Vacancies", command=display_current_vacancies)
    refresh_vacancies_button.grid(row=2, column=0, pady=10)

    appointments_frame = tk.Frame(vacancies_window, relief="groove", borderwidth=1, padx=20, pady=20)
    appointments_frame.grid(row=0, column=2, padx=10, pady=10, sticky="nsew", rowspan=2)

    tk.Label(appointments_frame, text="Doctor's Appointments", font=("Segoe UI", 12, "bold")).grid(row=0, column=0, pady=10, columnspan=2, sticky="n")

    appointments_display_text = scrolledtext.ScrolledText(appointments_frame, wrap=tk.WORD, width=60, height=20)
    appointments_display_text.grid(row=1, column=0, pady=10, sticky="nsew")
    appointments_display_text.config(state=tk.DISABLED)  

    def display_appointments():
        cursor = db.cursor()
        cursor.execute("""
            SELECT a.appointment_datetime, p.full_name 
            FROM appointments a 
            JOIN patients p ON a.patient_id = p.patient_id 
            WHERE a.doc_user = %s 
            ORDER BY a.appointment_datetime ASC
        """, (doc_user,))
        appointments = cursor.fetchall()
        cursor.close()

        appointments_display_text.config(state=tk.NORMAL)
        appointments_display_text.delete(1.0, tk.END)  

        if appointments:
            for appointment in appointments:
                appointment_datetime = appointment[0]
                patient_name = appointment[1]

                formatted_datetime = appointment_datetime.strftime("%d-%m-%Y %H:%M")

                appointments_display_text.insert(tk.END, f"Appointment: {formatted_datetime}\nPatient: {patient_name}\n{'-'*40}\n")
        else:
            appointments_display_text.insert(tk.END, "No appointments scheduled.")

        appointments_display_text.config(state=tk.DISABLED)  

    refresh_appointments_button = tk.Button(appointments_frame, text="Refresh Appointments", command=display_appointments)
    refresh_appointments_button.grid(row=2, column=0, pady=10)

    display_appointments()

main_window = tk.Tk()
doctor_login()

